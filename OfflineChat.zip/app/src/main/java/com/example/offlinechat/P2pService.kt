package com.example.offlinechat

import android.Manifest
import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.media.audiofx.AcousticEchoCanceler
import android.net.Uri
import android.net.wifi.WpsInfo
import android.net.wifi.p2p.WifiP2pConfig
import android.net.wifi.p2p.WifiP2pDevice
import android.net.wifi.p2p.WifiP2pManager
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.OpenableColumns
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.EOFException
import java.io.File
import java.io.FileOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.net.SocketTimeoutException
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong
import kotlin.random.Random

/**
 * Owns the whole connection so it survives screen changes and the app going to background.
 *
 * TCP 8988  chat + call signalling  (writeUTF lines)
 *   M:<id>:<text>  A:<id>  H:<name>  C:REQ  C:ACC  C:REJ  C:END
 * TCP 8990  one short connection per file  (id, name, size, bytes -> 1-byte ack)
 * UDP 8989  voice, 16 kHz mono PCM16, 20 ms frames
 */
class P2pService : Service() {

    companion object {
        const val CHAT_PORT = 8988
        const val AUDIO_PORT = 8989
        const val FILE_PORT = 8990
        private const val SAMPLE_RATE = 16000
        private const val FRAME_BYTES = 640

        private const val CH_SERVICE = "svc"
        private const val CH_MSG = "msg"
        private const val CH_CALL = "call"
        private const val CH_NEARBY = "nearby"
        private const val NOTIF_SERVICE = 1
        private const val NOTIF_MSG = 2
        private const val NOTIF_CALL = 3
        private const val NOTIF_NEARBY = 4

        fun start(ctx: Context) =
            ContextCompat.startForegroundService(ctx, Intent(ctx, P2pService::class.java))

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, P2pService::class.java))
        }
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val writer = Executors.newSingleThreadExecutor().asCoroutineDispatcher()
    private val main = Handler(Looper.getMainLooper())

    private lateinit var prefs: Prefs
    private lateinit var p2p: WifiP2pManager
    private lateinit var channel: WifiP2pManager.Channel
    private lateinit var audioManager: AudioManager
    private lateinit var nm: NotificationManager

    private val linkStarted = AtomicBoolean(false)
    @Volatile private var socket: Socket? = null
    @Volatile private var serverSocket: ServerSocket? = null
    @Volatile private var fileServer: ServerSocket? = null
    @Volatile private var out: DataOutputStream? = null
    @Volatile private var peerAddress: InetAddress? = null

    private var manualDisconnect = false
    private var receiverRegistered = false
    private var autoJob: Job? = null
    private var connectToken = 0
    private var callToken = 0
    private var friendInRange = false
    private var lastNearbyNotify = 0L
    private val idGen = AtomicLong(0)

    private var udpSocket: DatagramSocket? = null
    private var recorder: AudioRecord? = null
    private val audioJobs = ArrayList<Job>()

    private val historyFile get() = File(filesDir, "chat.json")

    private fun ui(block: () -> Unit) { main.post { block() } }
    private fun toast(msg: String) = Hub.fire(Hub.Ev.TOAST, text = msg)

    private fun newId(): Long {
        val t = System.currentTimeMillis()
        return idGen.updateAndGet { if (t > it) t else it + 1 }
    }

    // =====================================================================
    // Lifecycle
    // =====================================================================

    override fun onCreate() {
        super.onCreate()
        Hub.service = this
        prefs = Prefs(this)
        nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        Hub.load(historyFile)
        createChannels()
        goForeground(false)

        p2p = getSystemService(Context.WIFI_P2P_SERVICE) as WifiP2pManager
        channel = p2p.initialize(this, Looper.getMainLooper(), null)

        val filter = IntentFilter().apply {
            addAction(WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION)
            addAction(WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION)
            addAction(WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION)
        }
        ContextCompat.registerReceiver(this, receiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED)
        receiverRegistered = true

        Hub.link = Hub.Link.IDLE
        Hub.status = "Not connected"
        startAuto()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        goForeground(Hub.call == Hub.Call.ACTIVE)
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        try { File(filesDir, "chat.json").writeText(Hub.toJson()) } catch (_: Exception) {}
        stopVibrate()
        stopAudio()
        linkStarted.set(false)
        closeLink()
        try { p2p.removeGroup(channel, null) } catch (_: Exception) {}
        if (receiverRegistered) {
            try { unregisterReceiver(receiver) } catch (_: Exception) {}
            receiverRegistered = false
        }
        Hub.service = null
        Hub.link = Hub.Link.IDLE
        Hub.call = Hub.Call.IDLE
        scope.cancel()
        writer.close()
    }

    // =====================================================================
    // Notifications / foreground
    // =====================================================================

    private fun createChannels() {
        if (Build.VERSION.SDK_INT < 26) return
        nm.createNotificationChannel(
            NotificationChannel(CH_SERVICE, "Connection", NotificationManager.IMPORTANCE_LOW)
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_MSG, "Messages", NotificationManager.IMPORTANCE_HIGH)
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_CALL, "Calls", NotificationManager.IMPORTANCE_HIGH)
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_NEARBY, "Friend nearby", NotificationManager.IMPORTANCE_HIGH)
        )
    }

    private fun openAppIntent(): PendingIntent = PendingIntent.getActivity(
        this, 0,
        Intent(this, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    private fun serviceNotification(): Notification =
        NotificationCompat.Builder(this, CH_SERVICE)
            .setSmallIcon(android.R.drawable.stat_notify_chat)
            .setContentTitle("Offline Chat")
            .setContentText(Hub.status)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(openAppIntent())
            .build()

    private fun updateNotif() {
        try { nm.notify(NOTIF_SERVICE, serviceNotification()) } catch (_: Exception) {}
    }

    private fun goForeground(mic: Boolean) {
        val n = serviceNotification()
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                var type = ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE
                if (mic && Build.VERSION.SDK_INT >= 30) {
                    type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
                }
                startForeground(NOTIF_SERVICE, n, type)
            } else {
                startForeground(NOTIF_SERVICE, n)
            }
        } catch (e: Exception) {
            if (mic) {
                // Could not add the microphone type; keep the base service alive.
                try { goForeground(false) } catch (_: Exception) {}
            }
        }
    }

    private fun notifyMessage(m: Msg) {
        if (!prefs.notifyMessages || Hub.uiVisible) return
        val body = if (m.kind == 1) "📎 ${m.text}" else m.text
        val n = NotificationCompat.Builder(this, CH_MSG)
            .setSmallIcon(android.R.drawable.stat_notify_chat)
            .setContentTitle(Hub.peerName.ifBlank { "New message" })
            .setContentText(body)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(openAppIntent())
            .build()
        try { nm.notify(NOTIF_MSG, n) } catch (_: Exception) {}
    }

    fun cancelMessageNotification() = nm.cancel(NOTIF_MSG)

    private fun notifyIncomingCall() {
        if (Hub.uiVisible) return
        val n = NotificationCompat.Builder(this, CH_CALL)
            .setSmallIcon(android.R.drawable.stat_sys_phone_call)
            .setContentTitle("Incoming call")
            .setContentText(Hub.peerName.ifBlank { "Offline Chat" })
            .setCategory(NotificationCompat.CATEGORY_CALL)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setTimeoutAfter(40_000)
            .setAutoCancel(true)
            .setContentIntent(openAppIntent())
            .build()
        try { nm.notify(NOTIF_CALL, n) } catch (_: Exception) {}
    }

    @Suppress("DEPRECATION")
    private fun vibrator(): Vibrator? = try {
        if (Build.VERSION.SDK_INT >= 31) {
            (getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
        } else {
            getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        }
    } catch (_: Exception) { null }

    @Suppress("DEPRECATION")
    private fun startVibrate() {
        if (!prefs.vibrate) return
        val pattern = longArrayOf(0, 600, 400, 600, 400, 600, 400, 600)
        if (Build.VERSION.SDK_INT >= 26) {
            vibrator()?.vibrate(VibrationEffect.createWaveform(pattern, -1))
        } else {
            vibrator()?.vibrate(pattern, -1)
        }
    }

    private fun stopVibrate() { try { vibrator()?.cancel() } catch (_: Exception) {} }

    // =====================================================================
    // Link state helpers
    // =====================================================================

    private fun setLink(l: Hub.Link, text: String) {
        Hub.link = l
        if (l == Hub.Link.CONNECTED) {
            friendInRange = true
            nm.cancel(NOTIF_NEARBY)
        }
        Hub.status = text
        Hub.fire(Hub.Ev.STATE)
        updateNotif()
    }

    private fun hasP2pPermission(): Boolean {
        val perm = if (Build.VERSION.SDK_INT >= 33) {
            Manifest.permission.NEARBY_WIFI_DEVICES
        } else {
            Manifest.permission.ACCESS_FINE_LOCATION
        }
        return ContextCompat.checkSelfPermission(this, perm) == PackageManager.PERMISSION_GRANTED
    }

    private fun hasMic() = ContextCompat.checkSelfPermission(
        this, Manifest.permission.RECORD_AUDIO
    ) == PackageManager.PERMISSION_GRANTED

    private fun reasonText(r: Int) = when (r) {
        WifiP2pManager.P2P_UNSUPPORTED -> "Wi-Fi Direct not supported"
        WifiP2pManager.BUSY -> "device busy, try again"
        else -> "error $r"
    }

    // =====================================================================
    // Wi-Fi P2P: discovery, auto-connect, connect
    // =====================================================================

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION -> {
                    val st = intent.getIntExtra(WifiP2pManager.EXTRA_WIFI_STATE, -1)
                    if (st != WifiP2pManager.WIFI_P2P_STATE_ENABLED) toast("Turn on Wi-Fi to use Wi-Fi Direct")
                }
                WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION -> refreshPeers()
                WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION ->
                    p2p.requestConnectionInfo(channel, connectionListener)
            }
        }
    }

    /** Re-scans every 20 s while a saved device exists and we are not connected. */
    fun startAuto() {
        autoJob?.cancel()
        autoJob = scope.launch {
            while (isActive) {
                val idle = Hub.link == Hub.Link.IDLE || Hub.link == Hub.Link.SCANNING
                val wanted = prefs.savedAddress != null && idle &&
                    (prefs.nearbyAlert || (prefs.autoConnect && !manualDisconnect))
                if (wanted && hasP2pPermission()) {
                    withContext(Dispatchers.Main) { discover(false) }
                }
                delay(30_000)
            }
        }
    }

    fun scan() {
        manualDisconnect = false
        Hub.peers.clear()
        Hub.fire(Hub.Ev.PEERS)
        discover(true)
        scope.launch {
            delay(60_000)
            ui {
                if (Hub.link == Hub.Link.SCANNING) {
                    setLink(Hub.Link.IDLE, "Scan finished. Tap scan to search again.")
                }
            }
        }
    }

    @SuppressLint("MissingPermission")
    private fun discover(manual: Boolean) {
        if (!hasP2pPermission()) {
            if (manual) toast("Permission needed to find nearby devices")
            return
        }
        if (Hub.link == Hub.Link.CONNECTED || Hub.link == Hub.Link.CONNECTING) return
        try {
            p2p.discoverPeers(channel, object : WifiP2pManager.ActionListener {
                override fun onSuccess() {
                    if (Hub.link == Hub.Link.IDLE) setLink(Hub.Link.SCANNING, "Searching for devices…")
                }

                override fun onFailure(reason: Int) {
                    if (manual) toast("Scan failed: ${reasonText(reason)}. Is Wi-Fi on?")
                }
            })
        } catch (_: SecurityException) {
        }
    }

    @SuppressLint("MissingPermission")
    private fun refreshPeers() {
        if (!hasP2pPermission()) return
        try {
            p2p.requestPeers(channel) { list ->
                Hub.peers.clear()
                Hub.peers.addAll(list.deviceList)
                Hub.fire(Hub.Ev.PEERS)
                checkNearby()
                maybeAutoConnect()
            }
        } catch (_: SecurityException) {
        }
    }

    /** Notifies once when the saved friend's phone shows up in Wi-Fi Direct range (no internet used). */
    private fun checkNearby() {
        val addr = prefs.savedAddress ?: return
        if (Hub.link == Hub.Link.CONNECTED) {
            friendInRange = true
            return
        }
        val present = Hub.peers.any { it.deviceAddress == addr }
        if (!present) {
            friendInRange = false
            return
        }
        if (friendInRange) return
        friendInRange = true
        val now = System.currentTimeMillis()
        if (prefs.nearbyAlert && !Hub.uiVisible && now - lastNearbyNotify > 5 * 60_000L) {
            lastNearbyNotify = now
            notifyNearby()
        }
    }

    private fun notifyNearby() {
        val name = prefs.savedName ?: "Your friend"
        val n = NotificationCompat.Builder(this, CH_NEARBY)
            .setSmallIcon(android.R.drawable.stat_notify_chat)
            .setContentTitle("$name is nearby")
            .setContentText(
                if (prefs.autoConnect) "Connecting automatically…" else "Tap to open Offline Chat and connect"
            )
            .setCategory(NotificationCompat.CATEGORY_STATUS)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(openAppIntent())
            .build()
        try { nm.notify(NOTIF_NEARBY, n) } catch (_: Exception) {}
    }

    private fun maybeAutoConnect() {
        val addr = prefs.savedAddress ?: return
        if (!prefs.autoConnect || manualDisconnect) return
        if (Hub.link == Hub.Link.CONNECTED || Hub.link == Hub.Link.CONNECTING) return
        val dev = Hub.peers.firstOrNull {
            it.deviceAddress == addr && it.status == WifiP2pDevice.AVAILABLE
        } ?: return
        // Random delay so two phones don't both initiate in the same instant.
        scope.launch {
            delay(Random.nextLong(200, 2500))
            ui {
                if (Hub.link != Hub.Link.CONNECTED && Hub.link != Hub.Link.CONNECTING && !manualDisconnect) {
                    connectTo(dev, true)
                }
            }
        }
    }

    fun connectSaved() {
        val addr = prefs.savedAddress
        val dev = Hub.peers.firstOrNull { it.deviceAddress == addr }
        if (dev != null) connectTo(dev) else scan()
    }

    @SuppressLint("MissingPermission")
    fun connectTo(dev: WifiP2pDevice, auto: Boolean = false) {
        if (!hasP2pPermission()) return
        if (Hub.link == Hub.Link.CONNECTING || Hub.link == Hub.Link.CONNECTED) return
        manualDisconnect = false
        prefs.savedAddress = dev.deviceAddress
        prefs.savedName = dev.deviceName
        Hub.peerName = dev.deviceName.ifBlank { "Peer" }
        try { p2p.stopPeerDiscovery(channel, null) } catch (_: Exception) {}

        val cfg = WifiP2pConfig().apply {
            deviceAddress = dev.deviceAddress
            wps.setup = WpsInfo.PBC
        }
        setLink(Hub.Link.CONNECTING, "Connecting to ${Hub.peerName}…")
        val token = ++connectToken
        try {
            p2p.connect(channel, cfg, object : WifiP2pManager.ActionListener {
                override fun onSuccess() {}
                override fun onFailure(reason: Int) {
                    setLink(Hub.Link.IDLE, "Could not connect: ${reasonText(reason)}")
                    if (!auto) toast("Could not connect: ${reasonText(reason)}")
                }
            })
        } catch (_: SecurityException) {
            setLink(Hub.Link.IDLE, "Permission denied")
            return
        }
        // Give up if the other phone never accepts.
        scope.launch {
            delay(45_000)
            ui {
                if (token == connectToken && Hub.link == Hub.Link.CONNECTING && !linkStarted.get()) {
                    try { p2p.cancelConnect(channel, null) } catch (_: Exception) {}
                    setLink(Hub.Link.IDLE, "Connection timed out")
                }
            }
        }
    }

    fun disconnect() {
        manualDisconnect = true
        friendInRange = true // don't alert right after the user disconnected on purpose
        try { p2p.cancelConnect(channel, null) } catch (_: Exception) {}
        if (linkStarted.get()) {
            onLinkLost()
        } else {
            try { p2p.removeGroup(channel, null) } catch (_: Exception) {}
            setLink(Hub.Link.IDLE, "Disconnected")
        }
    }

    private val connectionListener = WifiP2pManager.ConnectionInfoListener { info ->
        if (info.groupFormed) {
            if (linkStarted.compareAndSet(false, true)) {
                setLink(Hub.Link.CONNECTING, "Connecting…")
                if (info.isGroupOwner) {
                    startServer()
                } else {
                    val host = info.groupOwnerAddress?.hostAddress
                    if (host != null) startClient(host) else onLinkLost()
                }
            }
        } else if (linkStarted.get()) {
            onLinkLost()
        }
    }

    // =====================================================================
    // TCP session (background threads only)
    // =====================================================================

    private fun startServer() {
        scope.launch {
            try {
                val ss = ServerSocket().apply {
                    reuseAddress = true
                    bind(InetSocketAddress(CHAT_PORT))
                }
                serverSocket = ss
                val client = ss.accept()
                try { ss.close() } catch (_: Exception) {}
                runSession(client)
            } catch (_: Exception) {
                onLinkLost()
            }
        }
    }

    private fun startClient(host: String) {
        scope.launch {
            repeat(15) {
                if (!linkStarted.get() || !isActive) return@launch
                try {
                    val s = Socket()
                    s.connect(InetSocketAddress(host, CHAT_PORT), 3000)
                    runSession(s)
                    return@launch
                } catch (_: Exception) {
                    delay(1000)
                }
            }
            onLinkLost()
        }
    }

    private suspend fun runSession(s: Socket) {
        try {
            s.tcpNoDelay = true
            s.keepAlive = true
            socket = s
            peerAddress = s.inetAddress
            out = DataOutputStream(BufferedOutputStream(s.getOutputStream()))
            val input = DataInputStream(BufferedInputStream(s.getInputStream()))
            startFileServer()

            withContext(Dispatchers.Main) {
                learnPeer()
                setLink(Hub.Link.CONNECTED, "Connected")
                toast("Connected")
            }
            sendHello()
            while (true) {
                handleIncoming(input.readUTF())
            }
        } catch (_: Exception) {
        } finally {
            onLinkLost()
        }
    }

    @SuppressLint("MissingPermission")
    private fun learnPeer() {
        if (!hasP2pPermission()) return
        try {
            p2p.requestGroupInfo(channel) { group ->
                if (group != null) {
                    val dev = if (group.isGroupOwner) group.clientList.firstOrNull() else group.owner
                    if (dev != null) {
                        prefs.savedAddress = dev.deviceAddress
                        if (Hub.peerName.isBlank()) Hub.peerName = dev.deviceName
                        if (prefs.savedName.isNullOrBlank()) prefs.savedName = dev.deviceName
                        Hub.fire(Hub.Ev.STATE)
                    }
                }
            }
        } catch (_: SecurityException) {
        }
    }

    private fun send(line: String, onSent: (() -> Unit)? = null) {
        scope.launch(writer) {
            try {
                val o = out ?: return@launch
                o.writeUTF(line)
                o.flush()
                if (onSent != null) ui { onSent() }
            } catch (_: Exception) {
                onLinkLost()
            }
        }
    }

    fun sendHello() = send("H:${prefs.displayName}")

    private fun closeLink() {
        try { socket?.close() } catch (_: Exception) {}
        try { serverSocket?.close() } catch (_: Exception) {}
        try { fileServer?.close() } catch (_: Exception) {}
        socket = null
        serverSocket = null
        fileServer = null
        out = null
        peerAddress = null
    }

    private fun onLinkLost() {
        if (!linkStarted.getAndSet(false)) return
        closeLink()
        ui {
            endCall(false)
            Hub.peers.clear()
            Hub.fire(Hub.Ev.PEERS)
            try { p2p.removeGroup(channel, null) } catch (_: Exception) {}
            setLink(Hub.Link.IDLE, "Disconnected")
            if (!manualDisconnect) toast("Connection lost")
        }
    }

    // =====================================================================
    // Messages
    // =====================================================================

    private val saveRunnable = Runnable {
        val json = Hub.toJson()
        scope.launch { try { historyFile.writeText(json) } catch (_: Exception) {} }
    }

    private fun scheduleSave() {
        main.removeCallbacks(saveRunnable)
        main.postDelayed(saveRunnable, 1000)
    }

    private fun addMsg(m: Msg) {
        Hub.messages.add(m)
        Hub.fire(Hub.Ev.MSG_ADDED, Hub.messages.size - 1)
        scheduleSave()
        if (!m.mine && m.kind != 2) notifyMessage(m)
    }

    private fun updateMsg(id: Long, status: Int) {
        val idx = Hub.messages.indexOfFirst { it.id == id && it.mine }
        if (idx < 0) return
        val m = Hub.messages[idx]
        if (status == -1 || m.status < status) {
            m.status = status
            Hub.fire(Hub.Ev.MSG_UPDATED, idx)
            scheduleSave()
        }
    }

    fun clearChat() {
        Hub.messages.clear()
        Hub.fire(Hub.Ev.MSG_RESET)
        scheduleSave()
    }

    fun sendText(text: String) {
        if (Hub.link != Hub.Link.CONNECTED || out == null) {
            toast("Not connected")
            return
        }
        val m = Msg(newId(), 0, text, true, System.currentTimeMillis(), 0)
        addMsg(m)
        send("M:${m.id}:$text") { updateMsg(m.id, 1) }
    }

    /** Runs on the socket thread. */
    private fun handleIncoming(line: String) {
        try {
            when {
                line.startsWith("M:") -> {
                    val p = line.split(":", limit = 3)
                    val id = p[1].toLong()
                    val text = p[2]
                    ui { addMsg(Msg(id, 0, text, false, System.currentTimeMillis(), 0)) }
                    send("A:$id")
                }
                line.startsWith("A:") -> {
                    val id = line.substring(2).toLong()
                    ui { updateMsg(id, 2) }
                }
                line.startsWith("H:") -> {
                    val name = line.substring(2).trim()
                    if (name.isNotEmpty()) ui {
                        Hub.peerName = name
                        prefs.savedName = name
                        Hub.fire(Hub.Ev.STATE)
                    }
                }
                line == "C:REQ" -> ui {
                    if (Hub.call == Hub.Call.IDLE && Hub.link == Hub.Link.CONNECTED) {
                        Hub.call = Hub.Call.INCOMING
                        Hub.fire(Hub.Ev.CALL)
                        startVibrate()
                        notifyIncomingCall()
                    } else {
                        send("C:REJ")
                    }
                }
                line == "C:ACC" -> ui { if (Hub.call == Hub.Call.OUTGOING) beginCall() }
                line == "C:REJ" || line == "C:END" -> ui { endCall(false) }
            }
        } catch (_: Exception) {
        }
    }

    // =====================================================================
    // File transfer
    // =====================================================================

    private fun startFileServer() {
        scope.launch {
            try {
                val fs = ServerSocket().apply {
                    reuseAddress = true
                    bind(InetSocketAddress(FILE_PORT))
                }
                fileServer = fs
                while (isActive && linkStarted.get()) {
                    val c = fs.accept()
                    scope.launch { receiveFile(c) }
                }
            } catch (_: Exception) {
            }
        }
    }

    private fun safeName(n: String): String {
        val cleaned = n.replace(Regex("[\\\\/:*?\"<>|\\u0000]"), "_").trim()
        return cleaned.ifEmpty { "file" }
    }

    private fun uniqueFile(dir: File, name: String): File {
        var f = File(dir, name)
        if (!f.exists()) return f
        val dot = name.lastIndexOf('.')
        val base = if (dot > 0) name.substring(0, dot) else name
        val ext = if (dot > 0) name.substring(dot) else ""
        var i = 1
        while (f.exists()) { f = File(dir, "$base ($i)$ext"); i++ }
        return f
    }

    private fun receiveFile(c: Socket) {
        try {
            if (c.inetAddress != peerAddress) return // only accept from the connected peer
            c.soTimeout = 30_000
            val din = DataInputStream(BufferedInputStream(c.getInputStream()))
            val id = din.readLong()
            val name = safeName(din.readUTF())
            val size = din.readLong()
            val dir = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: filesDir
            dir.mkdirs()
            val dest = uniqueFile(dir, name)
            FileOutputStream(dest).use { fos ->
                val buf = ByteArray(16 * 1024)
                var left = size
                while (left > 0) {
                    val n = din.read(buf, 0, minOf(buf.size.toLong(), left).toInt())
                    if (n < 0) throw EOFException()
                    fos.write(buf, 0, n)
                    left -= n
                }
            }
            c.getOutputStream().apply { write(1); flush() }
            ui { addMsg(Msg(id, 1, dest.name, false, System.currentTimeMillis(), 0, dest.absolutePath, size)) }
        } catch (_: Exception) {
            ui { toast("File receive failed") }
        } finally {
            try { c.close() } catch (_: Exception) {}
        }
    }

    fun sendFile(uri: Uri) {
        val peer = peerAddress
        if (Hub.link != Hub.Link.CONNECTED || peer == null) {
            toast("Not connected")
            return
        }
        scope.launch {
            var name = "file"
            var size = -1L
            try {
                contentResolver.query(uri, null, null, null, null)?.use { c ->
                    if (c.moveToFirst()) {
                        val ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                        val si = c.getColumnIndex(OpenableColumns.SIZE)
                        if (ni >= 0) name = c.getString(ni) ?: name
                        if (si >= 0 && !c.isNull(si)) size = c.getLong(si)
                    }
                }
                if (size < 0) {
                    size = contentResolver.openAssetFileDescriptor(uri, "r")?.use { it.length } ?: -1L
                }
            } catch (_: Exception) {
            }
            if (size < 0) {
                ui { toast("Cannot read this file") }
                return@launch
            }
            val id = newId()
            val shownName = safeName(name)
            ui { addMsg(Msg(id, 1, shownName, true, System.currentTimeMillis(), 0, uri.toString(), size)) }
            try {
                Socket().use { s ->
                    s.connect(InetSocketAddress(peer, FILE_PORT), 5000)
                    s.soTimeout = 60_000
                    val dout = DataOutputStream(BufferedOutputStream(s.getOutputStream(), 64 * 1024))
                    dout.writeLong(id)
                    dout.writeUTF(shownName)
                    dout.writeLong(size)
                    val ins = contentResolver.openInputStream(uri) ?: throw EOFException()
                    ins.use { src ->
                        val buf = ByteArray(16 * 1024)
                        var left = size
                        while (left > 0) {
                            val n = src.read(buf, 0, minOf(buf.size.toLong(), left).toInt())
                            if (n < 0) throw EOFException()
                            dout.write(buf, 0, n)
                            left -= n
                        }
                    }
                    dout.flush()
                    ui { updateMsg(id, 1) }
                    if (s.getInputStream().read() == 1) ui { updateMsg(id, 2) }
                }
            } catch (_: Exception) {
                ui {
                    updateMsg(id, -1)
                    toast("File send failed")
                }
            }
        }
    }

    // =====================================================================
    // Voice call
    // =====================================================================

    fun startCall() {
        if (Hub.link != Hub.Link.CONNECTED || Hub.call != Hub.Call.IDLE) return
        Hub.call = Hub.Call.OUTGOING
        Hub.fire(Hub.Ev.CALL)
        send("C:REQ")
        val token = ++callToken
        scope.launch {
            delay(40_000)
            ui { if (token == callToken && Hub.call == Hub.Call.OUTGOING) endCall(true) }
        }
    }

    fun acceptCall() {
        if (Hub.call != Hub.Call.INCOMING) return
        stopVibrate()
        nm.cancel(NOTIF_CALL)
        send("C:ACC")
        beginCall()
    }

    private fun beginCall() {
        callToken++
        Hub.call = Hub.Call.ACTIVE
        Hub.muted = false
        Hub.speaker = prefs.speakerDefault
        Hub.callStartMs = SystemClock.elapsedRealtime()
        goForeground(true)
        startAudio()
        Hub.fire(Hub.Ev.CALL)
    }

    fun endCall(notify: Boolean) {
        val prev = Hub.call
        if (prev == Hub.Call.IDLE) return
        if (notify && Hub.link == Hub.Link.CONNECTED) {
            send(if (prev == Hub.Call.INCOMING) "C:REJ" else "C:END")
        }
        callToken++
        stopVibrate()
        nm.cancel(NOTIF_CALL)
        stopAudio()
        Hub.call = Hub.Call.IDLE

        val secs = (SystemClock.elapsedRealtime() - Hub.callStartMs) / 1000
        val text = when (prev) {
            Hub.Call.ACTIVE -> "Voice call · %02d:%02d".format(secs / 60, secs % 60)
            Hub.Call.OUTGOING -> "Call not answered"
            else -> if (notify) "Declined call" else "Missed call"
        }
        addMsg(Msg(newId(), 2, text, false, System.currentTimeMillis(), 0))
        if (prev == Hub.Call.ACTIVE) goForeground(false)
        Hub.fire(Hub.Ev.CALL)
    }

    fun toggleMute() {
        Hub.muted = !Hub.muted
        Hub.fire(Hub.Ev.CALL)
    }

    fun toggleSpeaker() {
        Hub.speaker = !Hub.speaker
        applySpeaker()
        Hub.fire(Hub.Ev.CALL)
    }

    @Suppress("DEPRECATION")
    private fun applySpeaker() {
        audioManager.isSpeakerphoneOn = Hub.speaker
    }

    @SuppressLint("MissingPermission")
    private fun startAudio() {
        val peer = peerAddress
        if (peer == null || !hasMic()) {
            toast("Microphone permission is required for calls")
            endCall(true)
            return
        }
        try {
            audioManager.mode = AudioManager.MODE_IN_COMMUNICATION
            applySpeaker()

            val sock = DatagramSocket(null).apply {
                reuseAddress = true
                bind(InetSocketAddress(AUDIO_PORT))
                soTimeout = 1000
            }
            udpSocket = sock

            val minRec = AudioRecord.getMinBufferSize(
                SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
            )
            val rec = AudioRecord(
                MediaRecorder.AudioSource.VOICE_COMMUNICATION, SAMPLE_RATE,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT,
                maxOf(minRec, FRAME_BYTES * 4)
            )
            if (rec.state != AudioRecord.STATE_INITIALIZED) {
                rec.release()
                sock.close()
                toast("Microphone unavailable")
                endCall(true)
                return
            }
            if (AcousticEchoCanceler.isAvailable()) {
                AcousticEchoCanceler.create(rec.audioSessionId)?.enabled = true
            }
            recorder = rec

            val minTrack = AudioTrack.getMinBufferSize(
                SAMPLE_RATE, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT
            )
            val trk = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(SAMPLE_RATE)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(maxOf(minTrack, FRAME_BYTES * 4))
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()

            rec.startRecording()
            trk.play()

            // Microphone -> UDP
            audioJobs += scope.launch {
                val buf = ByteArray(FRAME_BYTES)
                val pkt = DatagramPacket(buf, buf.size, peer, AUDIO_PORT)
                try {
                    while (isActive) {
                        val n = rec.read(buf, 0, buf.size)
                        if (n <= 0) break
                        if (!Hub.muted) {
                            pkt.length = n
                            sock.send(pkt)
                        }
                    }
                } catch (_: Exception) {
                } finally {
                    try { rec.stop() } catch (_: Exception) {}
                    rec.release()
                }
            }

            // UDP -> speaker
            audioJobs += scope.launch {
                val buf = ByteArray(2048)
                val pkt = DatagramPacket(buf, buf.size)
                try {
                    while (isActive) {
                        try {
                            pkt.length = buf.size
                            sock.receive(pkt)
                            trk.write(pkt.data, 0, pkt.length)
                        } catch (_: SocketTimeoutException) {
                        }
                    }
                } catch (_: Exception) {
                } finally {
                    try { trk.stop() } catch (_: Exception) {}
                    trk.release()
                }
            }
        } catch (e: Exception) {
            toast("Audio start failed: ${e.message}")
            endCall(true)
        }
    }

    @Suppress("DEPRECATION")
    private fun stopAudio() {
        try { recorder?.stop() } catch (_: Exception) {} // unblocks rec.read()
        recorder = null
        try { udpSocket?.close() } catch (_: Exception) {} // unblocks receive()
        udpSocket = null
        audioJobs.forEach { it.cancel() }
        audioJobs.clear()
        try { audioManager.mode = AudioManager.MODE_NORMAL } catch (_: Exception) {}
        try { audioManager.isSpeakerphoneOn = false } catch (_: Exception) {}
    }
}


/** Restarts the background service after a reboot so friend-nearby alerts keep working. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        val p = Prefs(context)
        if (p.savedAddress != null && (p.nearbyAlert || p.autoConnect)) {
            try { P2pService.start(context) } catch (_: Exception) {}
        }
    }
}
