package com.example.offlinechat

import android.Manifest
import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.animation.ValueAnimator
import android.widget.ImageView
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.net.wifi.p2p.WifiP2pDevice
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.appcompat.widget.SwitchCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity(), Hub.Listener {

    private enum class Page { CONNECT, CHAT, SETTINGS }

    private var page = Page.CONNECT
    private var pageBeforeSettings = Page.CONNECT
    private var prevLink = Hub.Link.IDLE

    private lateinit var prefs: Prefs
    private val timeFmt = SimpleDateFormat("HH:mm", Locale.getDefault())
    private val ticker = Handler(Looper.getMainLooper())

    // views
    private lateinit var root: View
    private lateinit var statusSpacer: View
    private lateinit var content: View
    private lateinit var pageConnect: View
    private lateinit var pageChat: View
    private lateinit var pageSettings: View
    private lateinit var tvConnIcon: ImageView
    private lateinit var ring1: View
    private lateinit var ring2: View
    private val pulseAnims = ArrayList<ObjectAnimator>()
    private lateinit var tvConnTitle: TextView
    private lateinit var tvConnHint: TextView
    private lateinit var savedCard: View
    private lateinit var tvSavedName: TextView
    private lateinit var btnSavedConnect: View
    private lateinit var btnScan: TextView
    private lateinit var scanProgress: ProgressBar
    private lateinit var peerList: ListView
    private lateinit var tvEmpty: TextView
    private lateinit var btnOpenChat: View
    private lateinit var chatAvatar: TextView
    private lateinit var tvChatName: TextView
    private lateinit var tvChatStatus: TextView
    private lateinit var banner: View
    private lateinit var rvChat: RecyclerView
    private lateinit var etInput: EditText
    private lateinit var settingsList: LinearLayout
    private lateinit var callOverlay: View
    private lateinit var tvCallAvatar: TextView
    private lateinit var tvCallName: TextView
    private lateinit var tvCallState: TextView
    private lateinit var btnMute: ImageView
    private lateinit var btnSpeaker: ImageView
    private lateinit var btnAccept: ImageView
    private lateinit var btnEnd: ImageView

    private lateinit var chatAdapter: ChatAdapter
    private lateinit var peerAdapter: PeerAdapter

    // permissions
    private var pendingAction: (() -> Unit)? = null
    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            pendingAction?.invoke()
            pendingAction = null
        }
    private val pickFile =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            if (uri != null) Hub.service?.sendFile(uri)
        }

    // =====================================================================
    // Lifecycle
    // =====================================================================

    override fun onCreate(savedInstanceState: Bundle?) {
        prefs = Prefs(this)
        AppCompatDelegate.setDefaultNightMode(prefs.themeMode)
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        setContentView(R.layout.activity_main)

        bindViews()
        setupInsets()
        styleViews()
        setupLists()
        setupClicks()

        P2pService.start(this)
        requestStartupPermissions()

        page = if (savedInstanceState != null) {
            Page.values()[savedInstanceState.getInt("page", 0)]
        } else if (Hub.link == Hub.Link.CONNECTED) Page.CHAT else Page.CONNECT
        pageBeforeSettings = if (Hub.link == Hub.Link.CONNECTED) Page.CHAT else Page.CONNECT
        showPage(page)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when (page) {
                    Page.SETTINGS -> showPage(pageBeforeSettings)
                    Page.CONNECT -> if (Hub.link == Hub.Link.CONNECTED) showPage(Page.CHAT) else finish()
                    Page.CHAT -> finish()
                }
            }
        })
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt("page", page.ordinal)
    }

    override fun onStart() {
        super.onStart()
        Hub.uiVisible = true
        Hub.addListener(this)
        prevLink = Hub.link
        Hub.service?.cancelMessageNotification()
        renderAll()
        if (Hub.messages.isNotEmpty()) rvChat.scrollToPosition(Hub.messages.size - 1)
    }

    override fun onStop() {
        super.onStop()
        Hub.uiVisible = false
        Hub.removeListener(this)
        ticker.removeCallbacksAndMessages(null)
        pulse(false)
    }

    // =====================================================================
    // Setup
    // =====================================================================

    private fun bindViews() {
        root = findViewById(R.id.root)
        statusSpacer = findViewById(R.id.statusSpacer)
        content = findViewById(R.id.content)
        pageConnect = findViewById(R.id.pageConnect)
        pageChat = findViewById(R.id.pageChat)
        pageSettings = findViewById(R.id.pageSettings)
        tvConnIcon = findViewById(R.id.ivConnIcon)
        ring1 = findViewById(R.id.ring1)
        ring2 = findViewById(R.id.ring2)
        tvConnTitle = findViewById(R.id.tvConnTitle)
        tvConnHint = findViewById(R.id.tvConnHint)
        savedCard = findViewById(R.id.savedCard)
        tvSavedName = findViewById(R.id.tvSavedName)
        btnSavedConnect = findViewById(R.id.btnSavedConnect)
        btnScan = findViewById(R.id.btnScan)
        scanProgress = findViewById(R.id.scanProgress)
        peerList = findViewById(R.id.peerList)
        tvEmpty = findViewById(R.id.tvEmpty)
        btnOpenChat = findViewById(R.id.btnOpenChat)
        chatAvatar = findViewById(R.id.chatAvatar)
        tvChatName = findViewById(R.id.tvChatName)
        tvChatStatus = findViewById(R.id.tvChatStatus)
        banner = findViewById(R.id.banner)
        rvChat = findViewById(R.id.rvChat)
        etInput = findViewById(R.id.etInput)
        settingsList = findViewById(R.id.settingsList)
        callOverlay = findViewById(R.id.callOverlay)
        tvCallAvatar = findViewById(R.id.tvCallAvatar)
        tvCallName = findViewById(R.id.tvCallName)
        tvCallState = findViewById(R.id.tvCallState)
        btnMute = findViewById(R.id.btnMute)
        btnSpeaker = findViewById(R.id.btnSpeaker)
        btnAccept = findViewById(R.id.btnAccept)
        btnEnd = findViewById(R.id.btnEnd)
    }

    private fun setupInsets() {
        val night = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
            Configuration.UI_MODE_NIGHT_YES
        val controller = WindowCompat.getInsetsController(window, root)
        controller.isAppearanceLightStatusBars = false
        controller.isAppearanceLightNavigationBars = !night

        ViewCompat.setOnApplyWindowInsetsListener(root) { _, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            val ime = insets.getInsets(WindowInsetsCompat.Type.ime())
            statusSpacer.layoutParams.height = bars.top
            statusSpacer.requestLayout()
            content.setPadding(bars.left, 0, bars.right, maxOf(bars.bottom, ime.bottom))
            insets
        }
    }

    private fun styleViews() {
        btnScan.background = accentGrad(26)
        btnSavedConnect.background = accentGrad(19)
        savedCard.background = round(c(R.color.card), 16)
        btnOpenChat.background = accentGrad(26)
        findViewById<View>(R.id.btnSend).background = accentGrad(0, true)
        findViewById<View>(R.id.inputPill).background = round(c(R.color.input_bg), 26)
        findViewById<View>(R.id.inputPill).elevation = dp(2).toFloat()
        chatAvatar.background = circle(Color.parseColor("#33FFFFFF"))
        tvConnIcon.background = circle(Color.parseColor("#33FFFFFF"))
        ring1.background = circle(Color.WHITE)
        ring2.background = circle(Color.WHITE)
        tvCallAvatar.background = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(Color.parseColor("#1F9E8B"), Color.parseColor("#0B5D52"))
        ).apply { shape = GradientDrawable.OVAL }
        btnMute.background = circle(c(R.color.call_btn))
        btnSpeaker.background = circle(c(R.color.call_btn))
        btnAccept.background = circle(Color.parseColor("#25D366"))
        btnEnd.background = circle(c(R.color.danger))
    }

    private fun setupLists() {
        chatAdapter = ChatAdapter()
        rvChat.layoutManager = LinearLayoutManager(this).apply { stackFromEnd = true }
        rvChat.adapter = chatAdapter
        rvChat.itemAnimator = null

        peerAdapter = PeerAdapter()
        peerList.adapter = peerAdapter
        peerList.emptyView = tvEmpty
    }

    private fun setupClicks() {
        findViewById<View>(R.id.btnSettings1).setOnClickListener { openSettings() }
        findViewById<View>(R.id.btnSettings2).setOnClickListener { openSettings() }
        findViewById<View>(R.id.btnBack).setOnClickListener { showPage(pageBeforeSettings) }

        btnScan.setOnClickListener {
            if (Hub.link == Hub.Link.CONNECTED) {
                Hub.service?.disconnect()
            } else {
                ensureP2p { Hub.service?.scan() ?: toast("Starting… try again") }
            }
        }
        btnSavedConnect.setOnClickListener {
            ensureP2p { Hub.service?.connectSaved() }
        }
        btnOpenChat.setOnClickListener { showPage(Page.CHAT) }
        peerList.setOnItemClickListener { _, _, pos, _ ->
            val dev = Hub.peers.getOrNull(pos) ?: return@setOnItemClickListener
            ensureP2p { Hub.service?.connectTo(dev) }
        }

        findViewById<View>(R.id.chatHeader).setOnClickListener { showPage(Page.CONNECT) }
        banner.setOnClickListener { showPage(Page.CONNECT) }
        findViewById<View>(R.id.btnCall).setOnClickListener {
            if (Hub.link != Hub.Link.CONNECTED) {
                toast("Connect to a device first")
            } else {
                ensureMic { Hub.service?.startCall() }
            }
        }
        findViewById<View>(R.id.btnSend).setOnClickListener { sendText() }
        findViewById<View>(R.id.btnEmoji).setOnClickListener { showEmojiDialog() }
        findViewById<View>(R.id.btnAttach).setOnClickListener {
            if (Hub.link != Hub.Link.CONNECTED) toast("Not connected") else pickFile.launch("*/*")
        }

        btnMute.setOnClickListener { Hub.service?.toggleMute() }
        btnSpeaker.setOnClickListener { Hub.service?.toggleSpeaker() }
        btnAccept.setOnClickListener { ensureMic { Hub.service?.acceptCall() } }
        btnEnd.setOnClickListener { Hub.service?.endCall(true) }
    }

    // =====================================================================
    // Helpers
    // =====================================================================

    private fun c(id: Int) = ContextCompat.getColor(this, id)
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    private fun circle(color: Int) = GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        setColor(color)
    }

    private fun round(color: Int, radiusDp: Int) = GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
        cornerRadius = dp(radiusDp).toFloat()
        setColor(color)
    }

    private fun accentGrad(radiusDp: Int, oval: Boolean = false) = GradientDrawable(
        GradientDrawable.Orientation.TL_BR,
        intArrayOf(c(R.color.accent), c(R.color.accent_end))
    ).apply {
        if (oval) shape = GradientDrawable.OVAL else cornerRadius = dp(radiusDp).toFloat()
    }

    private fun bubbleBg(color: Int, mine: Boolean) = GradientDrawable().apply {
        setColor(color)
        val r = dp(16).toFloat()
        val t = dp(4).toFloat()
        cornerRadii = if (mine) floatArrayOf(r, r, r, r, t, t, r, r) else floatArrayOf(r, r, r, r, r, r, t, t)
    }

    private fun pulse(on: Boolean) {
        if (!on) {
            pulseAnims.forEach { it.cancel() }
            pulseAnims.clear()
            ring1.alpha = 0f
            ring2.alpha = 0f
            return
        }
        if (pulseAnims.isNotEmpty()) return
        listOf(ring1 to 0L, ring2 to 800L).forEach { (v, delay) ->
            val a = ObjectAnimator.ofPropertyValuesHolder(
                v,
                PropertyValuesHolder.ofFloat(View.SCALE_X, 0.7f, 1.3f),
                PropertyValuesHolder.ofFloat(View.SCALE_Y, 0.7f, 1.3f),
                PropertyValuesHolder.ofFloat(View.ALPHA, 0.4f, 0f)
            )
            a.duration = 1600
            a.startDelay = delay
            a.repeatCount = ValueAnimator.INFINITE
            pulseAnims.add(a)
            a.start()
        }
    }

    private fun selectable(): Drawable? {
        val tv = TypedValue()
        theme.resolveAttribute(android.R.attr.selectableItemBackground, tv, true)
        return ContextCompat.getDrawable(this, tv.resourceId)
    }

    private fun initial(name: String?) =
        name?.trim()?.firstOrNull()?.uppercase() ?: "?"

    private fun formatSize(b: Long): String = when {
        b >= 1L shl 20 -> "%.1f MB".format(b / 1048576.0)
        b >= 1L shl 10 -> "%.0f KB".format(b / 1024.0)
        else -> "$b B"
    }

    // =====================================================================
    // Permissions
    // =====================================================================

    private fun p2pPermission() =
        if (Build.VERSION.SDK_INT >= 33) Manifest.permission.NEARBY_WIFI_DEVICES
        else Manifest.permission.ACCESS_FINE_LOCATION

    private fun has(p: String) =
        ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

    private fun requestStartupPermissions() {
        val list = ArrayList<String>()
        if (!has(p2pPermission())) list.add(p2pPermission())
        if (Build.VERSION.SDK_INT >= 33 && !has(Manifest.permission.POST_NOTIFICATIONS)) {
            list.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        if (list.isNotEmpty()) {
            pendingAction = { Hub.service?.startAuto() }
            permissionLauncher.launch(list.toTypedArray())
        }
    }

    private fun ensureP2p(action: () -> Unit) {
        if (has(p2pPermission())) {
            action()
        } else {
            pendingAction = {
                if (has(p2pPermission())) action() else toast("Permission is required to find nearby devices")
            }
            permissionLauncher.launch(arrayOf(p2pPermission()))
        }
    }

    private fun ensureMic(action: () -> Unit) {
        if (has(Manifest.permission.RECORD_AUDIO)) {
            action()
        } else {
            pendingAction = {
                if (has(Manifest.permission.RECORD_AUDIO)) action() else toast("Microphone permission is required for calls")
            }
            permissionLauncher.launch(arrayOf(Manifest.permission.RECORD_AUDIO))
        }
    }

    // =====================================================================
    // Navigation & rendering
    // =====================================================================

    private fun openSettings() {
        if (page != Page.SETTINGS) pageBeforeSettings = page
        showPage(Page.SETTINGS)
    }

    private fun showPage(p: Page) {
        page = p
        pageConnect.visibility = if (p == Page.CONNECT) View.VISIBLE else View.GONE
        pageChat.visibility = if (p == Page.CHAT) View.VISIBLE else View.GONE
        pageSettings.visibility = if (p == Page.SETTINGS) View.VISIBLE else View.GONE
        val shown = when (p) { Page.CONNECT -> pageConnect; Page.CHAT -> pageChat; Page.SETTINGS -> pageSettings }
        shown.alpha = 0f
        shown.animate().alpha(1f).setDuration(180).start()
        if (p == Page.SETTINGS) rebuildSettings()
        renderAll()
        if (p == Page.CHAT && Hub.messages.isNotEmpty()) rvChat.scrollToPosition(Hub.messages.size - 1)
    }

    private fun renderAll() {
        renderConnect()
        renderChatHeader()
        renderCall()
        peerAdapter.notifyDataSetChanged()
        chatAdapter.notifyDataSetChanged()
    }

    private fun renderConnect() {
        val connected = Hub.link == Hub.Link.CONNECTED
        tvConnIcon.setImageResource(if (connected) R.drawable.ic_check else R.drawable.ic_wifi)
        pulse(Hub.link == Hub.Link.SCANNING || Hub.link == Hub.Link.CONNECTING)
        tvConnTitle.text = if (connected && Hub.peerName.isNotBlank()) "Connected to ${Hub.peerName}" else Hub.status
        tvConnHint.text = when (Hub.link) {
            Hub.Link.CONNECTED -> "You can chat, send files and call. Next time it reconnects automatically."
            Hub.Link.CONNECTING -> "If the other phone shows an invitation, accept it."
            Hub.Link.SCANNING -> "Keep both phones close, and open this screen on the other phone too."
            Hub.Link.IDLE -> "Turn on Wi-Fi on both phones, then scan. You only do this once."
        }
        scanProgress.visibility =
            if (Hub.link == Hub.Link.SCANNING || Hub.link == Hub.Link.CONNECTING) View.VISIBLE else View.INVISIBLE
        btnScan.text = if (connected) "Disconnect" else "Scan for devices"
        btnScan.background = if (connected) round(c(R.color.danger), 26) else accentGrad(26)
        btnOpenChat.visibility = if (connected) View.VISIBLE else View.GONE

        val saved = prefs.savedName ?: prefs.savedAddress
        if (!connected && prefs.savedAddress != null && saved != null) {
            savedCard.visibility = View.VISIBLE
            tvSavedName.text = saved
        } else {
            savedCard.visibility = View.GONE
        }
    }

    private fun renderChatHeader() {
        val connected = Hub.link == Hub.Link.CONNECTED
        val name = if (Hub.peerName.isNotBlank()) Hub.peerName else (prefs.savedName ?: "No device")
        tvChatName.text = name
        chatAvatar.text = initial(name)
        tvChatStatus.text = when {
            Hub.call == Hub.Call.ACTIVE -> "In call"
            connected -> "Connected · offline"
            else -> Hub.status
        }
        banner.visibility = if (connected) View.GONE else View.VISIBLE
    }

    private fun renderCall() {
        ticker.removeCallbacksAndMessages(null)
        if (Hub.call == Hub.Call.IDLE) {
            callOverlay.visibility = View.GONE
            renderChatHeader()
            return
        }
        callOverlay.visibility = View.VISIBLE
        val name = if (Hub.peerName.isNotBlank()) Hub.peerName else "Peer"
        tvCallName.text = name
        tvCallAvatar.text = initial(name)
        btnAccept.visibility = if (Hub.call == Hub.Call.INCOMING) View.VISIBLE else View.GONE
        btnMute.visibility = if (Hub.call == Hub.Call.ACTIVE) View.VISIBLE else View.GONE
        btnSpeaker.visibility = if (Hub.call == Hub.Call.ACTIVE) View.VISIBLE else View.GONE
        btnMute.setImageResource(if (Hub.muted) R.drawable.ic_mic_off else R.drawable.ic_mic)
        btnMute.background = circle(if (Hub.muted) Color.parseColor("#546E7A") else c(R.color.call_btn))
        btnSpeaker.background = circle(if (Hub.speaker) Color.parseColor("#546E7A") else c(R.color.call_btn))

        when (Hub.call) {
            Hub.Call.OUTGOING -> tvCallState.text = "Calling…"
            Hub.Call.INCOMING -> tvCallState.text = "Incoming voice call"
            else -> {
                val tick = object : Runnable {
                    override fun run() {
                        val s = (SystemClock.elapsedRealtime() - Hub.callStartMs) / 1000
                        tvCallState.text = "%02d:%02d".format(s / 60, s % 60)
                        ticker.postDelayed(this, 1000)
                    }
                }
                tick.run()
            }
        }
        renderChatHeader()
    }

    override fun onHub(ev: Hub.Ev, index: Int, text: String) {
        when (ev) {
            Hub.Ev.STATE -> {
                val link = Hub.link
                if (prevLink != Hub.Link.CONNECTED && link == Hub.Link.CONNECTED && page == Page.CONNECT) {
                    showPage(Page.CHAT)
                } else {
                    renderConnect()
                    renderChatHeader()
                }
                prevLink = link
            }
            Hub.Ev.PEERS -> peerAdapter.notifyDataSetChanged()
            Hub.Ev.MSG_ADDED -> {
                chatAdapter.notifyItemInserted(index)
                rvChat.scrollToPosition(index)
            }
            Hub.Ev.MSG_UPDATED -> chatAdapter.notifyItemChanged(index)
            Hub.Ev.MSG_RESET -> chatAdapter.notifyDataSetChanged()
            Hub.Ev.CALL -> renderCall()
            Hub.Ev.TOAST -> toast(text)
        }
    }

    // =====================================================================
    // Chat actions
    // =====================================================================

    private fun sendText() {
        val text = etInput.text.toString().trim()
        if (text.isEmpty()) return
        val svc = Hub.service
        if (svc == null) {
            toast("Service is starting, try again")
            return
        }
        svc.sendText(text)
        if (Hub.link == Hub.Link.CONNECTED) etInput.setText("")
    }

    private fun showEmojiDialog() {
        val emojis = listOf(
            "😀", "😂", "😍", "🥰", "😎", "😢", "😡", "🤔", "😴", "🙏", "👍", "👎",
            "👏", "🙌", "💪", "🎉", "❤️", "💔", "🔥", "⭐", "✅", "❌", "😅", "😉",
            "🤝", "👋", "😇", "🤣", "😭", "🥳"
        )
        lateinit var dialog: AlertDialog
        val grid = GridLayout(this).apply {
            columnCount = 6
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        emojis.forEach { e ->
            grid.addView(TextView(this).apply {
                text = e
                textSize = 26f
                gravity = Gravity.CENTER
                setPadding(dp(10), dp(8), dp(10), dp(8))
                setOnClickListener { etInput.append(e) }
            })
        }
        dialog = AlertDialog.Builder(this)
            .setView(grid)
            .setPositiveButton("Done", null)
            .create()
        dialog.show()
    }

    private fun openFile(m: Msg) {
        val path = m.path ?: return
        try {
            val uri: Uri = if (m.mine) {
                Uri.parse(path)
            } else {
                FileProvider.getUriForFile(this, "$packageName.fileprovider", File(path))
            }
            val intent = Intent(Intent.ACTION_VIEW)
                .setDataAndType(uri, contentResolver.getType(uri) ?: "*/*")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(intent)
        } catch (_: ActivityNotFoundException) {
            toast("No app can open this file")
        } catch (_: Exception) {
            toast("Cannot open this file")
        }
    }

    // =====================================================================
    // Settings page (built in code)
    // =====================================================================

    private fun section(title: String) {
        settingsList.addView(TextView(this).apply {
            text = title.uppercase()
            textSize = 12f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setTextColor(c(R.color.accent))
            setPadding(dp(20), dp(20), dp(20), dp(6))
        })
    }

    private fun textColumn(title: String, subtitle: String?): LinearLayout {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(TextView(this).apply {
            text = title
            textSize = 16f
            setTextColor(c(R.color.text_primary))
        })
        if (!subtitle.isNullOrEmpty()) {
            col.addView(TextView(this).apply {
                text = subtitle
                textSize = 13f
                setTextColor(c(R.color.text_secondary))
            })
        }
        return col
    }

    private fun row(title: String, subtitle: String?, onClick: (() -> Unit)?) {
        val v = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(12), dp(20), dp(12))
            addView(textColumn(title, subtitle))
            if (onClick != null) {
                background = selectable()
                setOnClickListener { onClick() }
            }
        }
        settingsList.addView(v)
    }

    private fun switchRow(title: String, subtitle: String?, checked: Boolean, onChange: (Boolean) -> Unit) {
        val sw = SwitchCompat(this).apply { isChecked = checked }
        val v = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(20), dp(12), dp(20), dp(12))
            background = selectable()
            addView(textColumn(title, subtitle), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            addView(sw)
            setOnClickListener { sw.toggle() }
        }
        sw.setOnCheckedChangeListener { _, isChecked -> onChange(isChecked) }
        settingsList.addView(v)
    }

    private fun confirm(title: String, msg: String, onYes: () -> Unit) {
        AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage(msg)
            .setPositiveButton("Yes") { _, _ -> onYes() }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun rebuildSettings() {
        settingsList.removeAllViews()

        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
            background = round(c(R.color.card), 18)
            addView(TextView(this@MainActivity).apply {
                text = initial(prefs.displayName)
                textSize = 24f
                gravity = Gravity.CENTER
                setTextColor(Color.WHITE)
                background = accentGrad(0, true)
                layoutParams = LinearLayout.LayoutParams(dp(60), dp(60))
            })
            addView(LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(16), 0, 0, 0)
                addView(TextView(this@MainActivity).apply {
                    text = prefs.displayName
                    textSize = 18f
                    typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
                    setTextColor(c(R.color.text_primary))
                })
                addView(TextView(this@MainActivity).apply {
                    text = if (Hub.link == Hub.Link.CONNECTED) "Connected · ${Hub.peerName}" else "Offline · not connected"
                    textSize = 13f
                    setTextColor(c(R.color.text_secondary))
                })
            })
        }
        settingsList.addView(head, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { setMargins(dp(16), dp(16), dp(16), 0) })

        section("Profile")
        row("Your name", prefs.displayName + "\nShown to the person you chat with") {
            val et = EditText(this).apply {
                setText(prefs.displayName)
                setSelection(text.length)
                setSingleLine()
            }
            val box = LinearLayout(this).apply {
                setPadding(dp(20), dp(8), dp(20), 0)
                addView(et, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            }
            AlertDialog.Builder(this)
                .setTitle("Your name")
                .setView(box)
                .setPositiveButton("Save") { _, _ ->
                    val n = et.text.toString().trim()
                    if (n.isNotEmpty()) {
                        prefs.displayName = n
                        Hub.service?.sendHello()
                        rebuildSettings()
                    }
                }
                .setNegativeButton("Cancel", null)
                .show()
        }

        section("Connection")
        switchRow(
            "Auto-connect", "Reconnect to the last device automatically when it is nearby",
            prefs.autoConnect
        ) {
            prefs.autoConnect = it
            Hub.service?.startAuto()
        }
        row(
            "Saved device", prefs.savedName ?: prefs.savedAddress ?: "None yet — connect once and it is remembered",
            if (prefs.savedAddress != null) ({
                confirm("Forget device", "Forget ${prefs.savedName ?: "this device"}? You will need to connect manually again.") {
                    prefs.savedAddress = null
                    prefs.savedName = null
                    rebuildSettings()
                    renderConnect()
                }
            }) else null
        )
        row("Disconnect", "Close the current connection") {
            Hub.service?.disconnect()
            showPage(Page.CONNECT)
        }
        row("Wi-Fi settings", "Open system Wi-Fi settings") {
            startActivity(Intent(Settings.ACTION_WIFI_SETTINGS))
        }

        section("Calls")
        switchRow("Speaker by default", "Start calls on the loudspeaker", prefs.speakerDefault) { prefs.speakerDefault = it }
        switchRow("Vibrate on incoming call", null, prefs.vibrate) { prefs.vibrate = it }

        section("Notifications")
        switchRow("Message notifications", "Show a notification when the app is in the background", prefs.notifyMessages) {
            prefs.notifyMessages = it
        }
        switchRow(
            "Friend nearby alert",
            "Get a notification when your saved friend comes within Wi-Fi Direct range. Scans every 30 s (uses some battery).",
            prefs.nearbyAlert
        ) {
            prefs.nearbyAlert = it
            Hub.service?.startAuto()
        }
        row("System notification settings", "Sound, importance, lock screen") {
            startActivity(
                Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                    .putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
            )
        }

        section("Appearance")
        val themeNames = arrayOf("System default", "Light", "Dark")
        val themeModes = intArrayOf(
            AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM,
            AppCompatDelegate.MODE_NIGHT_NO,
            AppCompatDelegate.MODE_NIGHT_YES
        )
        row("Theme", themeNames[themeModes.indexOf(prefs.themeMode).coerceAtLeast(0)]) {
            AlertDialog.Builder(this)
                .setTitle("Theme")
                .setSingleChoiceItems(themeNames, themeModes.indexOf(prefs.themeMode).coerceAtLeast(0)) { d, which ->
                    prefs.themeMode = themeModes[which]
                    d.dismiss()
                    AppCompatDelegate.setDefaultNightMode(themeModes[which])
                }
                .show()
        }

        section("Storage")
        val dir = getExternalFilesDir(android.os.Environment.DIRECTORY_DOWNLOADS)?.absolutePath ?: filesDir.absolutePath
        row("Received files", dir, null)
        row("Clear chat history", "Delete all messages on this phone") {
            confirm("Clear chat", "Delete all messages? Received files are kept.") {
                Hub.service?.clearChat()
                toast("Chat cleared")
            }
        }

        section("Background")
        row("Battery optimisation", "Allow the app to keep the connection alive in the background") {
            try {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            } catch (_: Exception) {
                toast("Not available on this device")
            }
        }
        row("Stop background service", "Disconnect and fully close the app") {
            confirm("Stop service", "This disconnects the current chat and closes the app.") {
                P2pService.stop(this)
                finishAndRemoveTask()
            }
        }

        section("About")
        row(
            "How to use",
            "1. Turn on Wi-Fi on both phones.\n" +
                "2. Open the app on both and tap Scan for devices.\n" +
                "3. Tap the other phone and accept the invitation there.\n" +
                "4. Done — next time it reconnects by itself."
        ) {
            AlertDialog.Builder(this)
                .setTitle("How to use")
                .setMessage(
                    "1. Turn on Wi-Fi on both phones (no internet needed).\n\n" +
                        "2. Open the app on both phones and tap “Scan for devices”.\n\n" +
                        "3. Tap the other phone's name and accept the invitation on that phone.\n\n" +
                        "4. Chat, send files, or tap the phone icon to call.\n\n" +
                        "Next time, with Auto-connect on, the phones reconnect by themselves when they are near each other."
                )
                .setPositiveButton("OK", null)
                .show()
        }
        row("App permissions", "Open system app settings") {
            startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                    .setData(Uri.fromParts("package", packageName, null))
            )
        }
        row("Version", "1.0", null)
    }

    // =====================================================================
    // Adapters
    // =====================================================================

    private inner class PeerAdapter :
        ArrayAdapter<WifiP2pDevice>(this@MainActivity, 0, Hub.peers) {

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val d = Hub.peers[position]
            val row = LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(14), dp(12), dp(14), dp(12))
                background = round(c(R.color.card), 16)
            }
            row.addView(TextView(context).apply {
                text = initial(d.deviceName)
                textSize = 18f
                gravity = Gravity.CENTER
                setTextColor(Color.WHITE)
                background = circle(c(R.color.accent))
                layoutParams = LinearLayout.LayoutParams(dp(44), dp(44))
            })
            val col = LinearLayout(context).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(14), 0, 0, 0)
            }
            col.addView(TextView(context).apply {
                text = d.deviceName.ifBlank { d.deviceAddress }
                textSize = 16f
                setTextColor(c(R.color.text_primary))
            })
            col.addView(TextView(context).apply {
                text = when (d.status) {
                    WifiP2pDevice.CONNECTED -> "Connected"
                    WifiP2pDevice.INVITED -> "Invited"
                    WifiP2pDevice.FAILED -> "Failed"
                    WifiP2pDevice.UNAVAILABLE -> "Unavailable"
                    else -> "Available · tap to connect"
                }
                textSize = 13f
                setTextColor(c(R.color.text_secondary))
            })
            row.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            return android.widget.FrameLayout(context).apply {
                setPadding(dp(16), dp(5), dp(16), dp(5))
                addView(row)
            }
        }
    }

    private inner class ChatAdapter : RecyclerView.Adapter<ChatAdapter.VH>() {

        inner class VH(
            val row: LinearLayout,
            val bubble: LinearLayout,
            val fileRow: LinearLayout,
            val tvFileName: TextView,
            val tvFileSize: TextView,
            val tvText: TextView,
            val tvMeta: TextView
        ) : RecyclerView.ViewHolder(row)

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val ctx = parent.context
            val row = LinearLayout(ctx).apply {
                layoutParams = RecyclerView.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
                )
                orientation = LinearLayout.HORIZONTAL
                setPadding(dp(8), dp(2), dp(8), dp(2))
            }
            val bubble = LinearLayout(ctx).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(11), dp(7), dp(11), dp(5))
                elevation = dp(1).toFloat()
            }
            val fileRow = LinearLayout(ctx).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            fileRow.addView(ImageView(ctx).apply {
                setImageResource(R.drawable.ic_file)
                setColorFilter(c(R.color.accent))
                layoutParams = LinearLayout.LayoutParams(dp(34), dp(34))
            })
            val fileCol = LinearLayout(ctx).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(8), 0, 0, 0)
            }
            val tvFileName = TextView(ctx).apply {
                textSize = 15f
                maxWidth = (resources.displayMetrics.widthPixels * 0.55f).toInt()
                setTextColor(c(R.color.text_primary))
            }
            val tvFileSize = TextView(ctx).apply {
                textSize = 12f
                setTextColor(c(R.color.text_secondary))
            }
            fileCol.addView(tvFileName)
            fileCol.addView(tvFileSize)
            fileRow.addView(fileCol)

            val tvText = TextView(ctx).apply {
                setTextColor(c(R.color.text_primary))
                maxWidth = (resources.displayMetrics.widthPixels * 0.72f).toInt()
            }
            val tvMeta = TextView(ctx).apply {
                textSize = 11f
                gravity = Gravity.END
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
                )
            }
            bubble.addView(fileRow)
            bubble.addView(tvText)
            bubble.addView(tvMeta)
            row.addView(bubble, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ))
            return VH(row, bubble, fileRow, tvFileName, tvFileSize, tvText, tvMeta)
        }

        override fun onBindViewHolder(h: VH, position: Int) {
            val m = Hub.messages[position]
            h.bubble.setOnClickListener(null)
            h.bubble.isClickable = false

            if (m.kind == 2) {
                h.row.gravity = Gravity.CENTER
                h.bubble.background = round(c(R.color.divider), 12)
                h.fileRow.visibility = View.GONE
                h.tvMeta.visibility = View.GONE
                h.tvText.visibility = View.VISIBLE
                h.tvText.textSize = 13f
                h.tvText.text = m.text
                h.tvText.setTextColor(c(R.color.text_secondary))
                return
            }

            h.row.gravity = if (m.mine) Gravity.END else Gravity.START
            h.bubble.background = bubbleBg(c(if (m.mine) R.color.bubble_me else R.color.bubble_other), m.mine)
            h.tvMeta.visibility = View.VISIBLE
            h.tvText.setTextColor(c(R.color.text_primary))

            if (m.kind == 1) {
                h.fileRow.visibility = View.VISIBLE
                h.tvText.visibility = View.GONE
                h.tvFileName.text = m.text
                h.tvFileSize.text = formatSize(m.size)
                h.bubble.setOnClickListener { openFile(m) }
            } else {
                h.fileRow.visibility = View.GONE
                h.tvText.visibility = View.VISIBLE
                h.tvText.textSize = 16f
                h.tvText.text = m.text
            }

            val time = timeFmt.format(Date(m.time))
            if (m.mine) {
                val tick = when (m.status) {
                    -1 -> "⚠"
                    0 -> "🕓"
                    1 -> "✓"
                    else -> "✓✓"
                }
                h.tvMeta.text = "$time  $tick"
                h.tvMeta.setTextColor(
                    when (m.status) {
                        2 -> c(R.color.tick_blue)
                        -1 -> c(R.color.danger)
                        else -> c(R.color.text_secondary)
                    }
                )
            } else {
                h.tvMeta.text = time
                h.tvMeta.setTextColor(c(R.color.text_secondary))
            }
        }

        override fun getItemCount() = Hub.messages.size
    }
}
