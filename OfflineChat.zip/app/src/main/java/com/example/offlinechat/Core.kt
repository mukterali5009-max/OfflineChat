package com.example.offlinechat

import android.content.Context
import android.net.wifi.p2p.WifiP2pDevice
import android.os.Build
import androidx.appcompat.app.AppCompatDelegate
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** kind: 0 = text, 1 = file, 2 = call log. status: -1 failed, 0 sending, 1 sent, 2 delivered */
data class Msg(
    val id: Long,
    val kind: Int,
    val text: String,
    val mine: Boolean,
    val time: Long,
    var status: Int = 0,
    val path: String? = null,
    val size: Long = 0
)

/**
 * Single source of truth shared by the service (writes) and the UI (reads).
 * Everything here is touched on the MAIN thread only.
 */
object Hub {
    enum class Link { IDLE, SCANNING, CONNECTING, CONNECTED }
    enum class Call { IDLE, OUTGOING, INCOMING, ACTIVE }
    enum class Ev { STATE, PEERS, MSG_ADDED, MSG_UPDATED, MSG_RESET, CALL, TOAST }

    interface Listener {
        fun onHub(ev: Ev, index: Int, text: String)
    }

    @Volatile var link = Link.IDLE
    var status = "Not connected"
    var peerName = ""

    @Volatile var call = Call.IDLE
    @Volatile var muted = false
    @Volatile var speaker = false
    var callStartMs = 0L

    @Volatile var uiVisible = false
    var service: P2pService? = null

    val peers = ArrayList<WifiP2pDevice>()
    val messages = ArrayList<Msg>()
    private val listeners = ArrayList<Listener>()

    fun addListener(l: Listener) { if (!listeners.contains(l)) listeners.add(l) }
    fun removeListener(l: Listener) { listeners.remove(l) }

    fun fire(ev: Ev, index: Int = -1, text: String = "") {
        for (l in ArrayList(listeners)) l.onHub(ev, index, text)
    }

    fun toJson(): String {
        val arr = JSONArray()
        for (m in messages.takeLast(500)) {
            arr.put(
                JSONObject()
                    .put("id", m.id).put("kind", m.kind).put("text", m.text)
                    .put("mine", m.mine).put("time", m.time).put("status", m.status)
                    .put("path", m.path ?: JSONObject.NULL).put("size", m.size)
            )
        }
        return arr.toString()
    }

    fun load(file: File) {
        if (messages.isNotEmpty() || !file.exists()) return
        try {
            val arr = JSONArray(file.readText())
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                messages.add(
                    Msg(
                        o.getLong("id"), o.getInt("kind"), o.getString("text"),
                        o.getBoolean("mine"), o.getLong("time"),
                        o.getInt("status").let { if (it == 0) -1 else it },
                        if (o.isNull("path")) null else o.getString("path"),
                        o.optLong("size", 0)
                    )
                )
            }
        } catch (_: Exception) {
        }
    }
}

class Prefs(ctx: Context) {
    private val sp = ctx.applicationContext.getSharedPreferences("settings", Context.MODE_PRIVATE)

    var displayName: String
        get() = sp.getString("name", null)?.takeIf { it.isNotBlank() } ?: Build.MODEL
        set(v) = sp.edit().putString("name", v.trim()).apply()

    var autoConnect: Boolean
        get() = sp.getBoolean("auto", true)
        set(v) = sp.edit().putBoolean("auto", v).apply()

    var savedAddress: String?
        get() = sp.getString("saved_addr", null)
        set(v) = sp.edit().putString("saved_addr", v).apply()

    var savedName: String?
        get() = sp.getString("saved_name", null)
        set(v) = sp.edit().putString("saved_name", v).apply()

    var speakerDefault: Boolean
        get() = sp.getBoolean("speaker", false)
        set(v) = sp.edit().putBoolean("speaker", v).apply()

    var vibrate: Boolean
        get() = sp.getBoolean("vibrate", true)
        set(v) = sp.edit().putBoolean("vibrate", v).apply()

    var notifyMessages: Boolean
        get() = sp.getBoolean("notify", true)
        set(v) = sp.edit().putBoolean("notify", v).apply()

    var nearbyAlert: Boolean
        get() = sp.getBoolean("nearby", true)
        set(v) = sp.edit().putBoolean("nearby", v).apply()

    var themeMode: Int
        get() = sp.getInt("theme", AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM)
        set(v) = sp.edit().putInt("theme", v).apply()
}
