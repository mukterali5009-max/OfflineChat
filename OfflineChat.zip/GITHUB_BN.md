# ফোন থেকে করলে (সবচেয়ে সহজ: মাত্র ২টি ফাইল আপলোড)

ফোনের ব্রাউজার ফোল্ডার আপলোড করতে পারে না। তাই কৌশল: **ZIP ফাইলটি নিজেই আপলোড** করুন, আর GitHub-এর বিল্ড নিজে ZIP খুলে অ্যাপ বানাবে।

1. github.com-এ অ্যাকাউন্ট খুলুন → **New repository** → নাম `OfflineChat` → **Public** → **Create repository**।
2. **আগে ZIP:** Repository পেজে **uploading an existing file** (বা Add file → Upload files) → ফোন থেকে `OfflineChat.zip` বাছুন (আনজিপ করবেন না) → **Commit changes**।
3. **তারপর workflow:** **Add file → Create new file** → নামের ঘরে হুবহু লিখুন `.github/workflows/build.yml` → নিচের বড় ঘরে `workflow_for_zip_upload.yml` ফাইলের পুরো লেখা পেস্ট করুন → **Commit changes**।
4. **Actions** ট্যাব → রান শেষ হওয়ার অপেক্ষা (৪–১০ মিনিট) → সবুজ টিক হলে রানে ক্লিক → নিচে **Artifacts → OfflineChat-apk** ডাউনলোড → ZIP-এ `app-debug.apk`।
5. APK দুই ফোনে ইনস্টল করুন।

> ক্রম গুরুত্বপূর্ণ: আগে ZIP, পরে workflow। উল্টো করলে প্রথম রান ZIP না পেয়ে ব্যর্থ হবে (তখন Actions → Run workflow চাপলেই চলবে)।
> ব্রাউজারে "Desktop site" চালু করলে GitHub-এর বাটনগুলো সহজে পাওয়া যায়।

---

# কম্পিউটার থেকে করলে (ফোল্ডার আপলোড)

# GitHub দিয়ে APK বানানোর ধাপ (কম্পিউটারে ব্রাউজার থেকে, কিছু ইনস্টল না করেই)

**কত সময় লাগবে:** ১৫–২০ মিনিট। **খরচ:** ফ্রি। **ইন্টারনেট:** শুধু এই বানানোর সময়।

## ধাপ ১ — GitHub অ্যাকাউন্ট
1. https://github.com খুলে **Sign up** করুন (ইমেইল, পাসওয়ার্ড, ইউজারনেম)।
2. ইমেইলে আসা কোড দিয়ে অ্যাকাউন্ট যাচাই করুন।

## ধাপ ২ — নতুন Repository
1. ডানদিকে উপরে **+** → **New repository**।
2. **Repository name:** `OfflineChat`
3. **Public** বাছুন (Public হলে Actions-এর ফ্রি সীমা বেশি)।
4. **Add a README file** টিক দেবেন না (ফাঁকা থাকবে)।
5. **Create repository** চাপুন।

## ধাপ ৩ — ফাইল আপলোড (এই ধাপে সবচেয়ে বেশি ভুল হয়)
1. `OfflineChat.zip` ফাইলটি আপনার কম্পিউটারে **Extract/Unzip** করুন। **ZIP ফাইল নিজে আপলোড করবেন না** — GitHub ZIP খুলে দেয় না।
2. আনজিপ করা ফোল্ডারের ভেতরে দেখবেন: `app` ফোল্ডার, `gradle` ফোল্ডার, `.github` ফোল্ডার, `build.gradle.kts`, `settings.gradle.kts`, `gradle.properties`, `.gitignore` ইত্যাদি।
3. নতুন Repository পেজে **uploading an existing file** লিঙ্কে চাপুন (অথবা **Add file → Upload files**)।
4. ফোল্ডারের **ভেতরের সবকিছু** সিলেক্ট (Ctrl+A) করে ব্রাউজারে টেনে ছাড়ুন (drag & drop)। বাইরের ফোল্ডারটি নয়, ভেতরের জিনিসগুলো।
5. সব ফাইল আপলোড শেষ হওয়া পর্যন্ত অপেক্ষা করুন। নিচে **Commit changes** বাটন চাপুন।
6. **`.github` ফোল্ডারটি আপলোড হয়নি?** (ফোল্ডারের নাম `.` দিয়ে শুরু হওয়ায় অনেক সময় লুকানো থাকে।) তাহলে হাতে বানান:
   - **Add file → Create new file**
   - নামের ঘরে লিখুন: `.github/workflows/build.yml` (স্ল্যাশ `/` লিখলেই ফোল্ডার তৈরি হয়ে যাবে)
   - নিচের লেখাটি হুবহু পেস্ট করুন, তারপর **Commit changes**:

```yaml
name: Build APK
on:
  push:
    branches: [ main ]
  workflow_dispatch:
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: 17
      - uses: gradle/actions/setup-gradle@v3
        with:
          gradle-version: 8.5
      - run: gradle assembleDebug
      - uses: actions/upload-artifact@v4
        with:
          name: OfflineChat-apk
          path: app/build/outputs/apk/debug/app-debug.apk
```

7. **যাচাই:** Repository-র প্রথম পেজে `app`, `gradle`, `.github`, `build.gradle.kts`, `settings.gradle.kts` দেখা যাচ্ছে কিনা দেখুন। `app` খুললে `src/main/...` থাকতে হবে।

## ধাপ ৪ — বিল্ড চালানো
1. উপরের **Actions** ট্যাবে চাপুন। ("I understand my workflows, go ahead and enable them" লেখা বাটন এলে সেটি চাপুন।)
2. বাঁদিকে **Build APK** বাছুন → ডানে **Run workflow** → সবুজ **Run workflow**।
   (ফাইল আপলোডের সাথে সাথে `main` ব্রাঞ্চে নিজে থেকেও চলতে পারে।)
3. তালিকায় নতুন একটি রান আসবে (হলুদ বৃত্ত = চলছে)। ৪–১০ মিনিট অপেক্ষা করুন।
4. **সবুজ টিক ✔** হলে সফল। **লাল ✖** হলে ব্যর্থ — নিচের "ব্যর্থ হলে" দেখুন।

## ধাপ ৫ — APK ডাউনলোড
1. সফল রানে ক্লিক করুন।
2. পেজের একদম নিচে **Artifacts** অংশে **OfflineChat-apk** আছে — ক্লিক করে ডাউনলোড করুন।
3. ডাউনলোড হওয়া ZIP খুলুন, ভেতরে `app-debug.apk`।

## ধাপ ৬ — ফোনে ইনস্টল
1. `app-debug.apk` ফোনে পাঠান (USB, ব্লুটুথ, Google Drive ইত্যাদি)। বন্ধুর ফোনেও একই APK পাঠান।
2. ফোনে APK ফাইলে চাপুন → **Install**। "Install unknown apps" অনুমতি চাইলে তা চালু করুন।
3. "Play Protect" সতর্কবার্তা এলে **Install anyway** দিন (কারণ অ্যাপটি Play Store থেকে নয়)।

## ব্যর্থ হলে (লাল ✖)
1. ব্যর্থ রানে ক্লিক → **build** জবে ক্লিক।
2. লাল চিহ্নওয়ালা ধাপ খুলুন এবং `error:` বা `e: ` দিয়ে শুরু হওয়া লাইনগুলো কপি করুন।
3. সেই লেখাটি আমাকে পাঠান — আমি কোড ঠিক করে দেব। (আমি কোডটি নিজে কম্পাইল করে দেখতে পারিনি, তাই প্রথমবার এরর আসা অস্বাভাবিক নয়।)

## সাধারণ ভুল
| ভুল | ফল |
|---|---|
| ZIP ফাইল সরাসরি আপলোড করা | Actions কিছুই খুঁজে পায় না; আনজিপ করে ভেতরের জিনিস আপলোড করুন |
| বাইরের ফোল্ডারসহ আপলোড (`OfflineChat/app/...`) | বিল্ড ফাইল খুঁজে পায় না; `settings.gradle.kts` Repository-র একদম প্রথম পেজে থাকতে হবে |
| `.github` ফোল্ডার বাদ পড়া | Actions ট্যাবে কোনো workflow দেখা যায় না; ধাপ ৩-এর ৬ নম্বর অনুসরণ করুন |
| ব্রাঞ্চের নাম `master` হলে | ম্যানুয়ালি **Run workflow** চাপুন (এতে ব্রাঞ্চ বাছাই করা যায়) |

## আপডেট করলে
কোড বদলালে সংশ্লিষ্ট ফাইলটি GitHub-এ খুলে ✏️ (Edit) দিয়ে বদলান বা নতুন করে আপলোড করুন → Commit → আবার ধাপ ৪–৫।
